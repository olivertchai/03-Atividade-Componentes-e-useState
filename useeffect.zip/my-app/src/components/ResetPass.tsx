import { View, StyleSheet, TextInput , Button,} from 'react-native'
import React , { useState , useEffect}from 'react'

export default function ResetPass() {
    const [password, setPassword] = useState('');  
    const [password1, setPassword1] = useState('');

    useEffect(() =>{
    const passwordIsValid= () =>{
        if(password || password1 <= 6){

        }    
    }
    },[]);

    return (
    <View>
         <TextInput
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            secureTextEntry 
            placeholder="Digite sua sen ha"
        />

        <TextInput
            style={styles.input}
            value={password1}
            onChangeText={setPassword1}
            secureTextEntry 
            placeholder="Digite sua senha"
        />
        <Button
            disabled
            title="reset"
            color="#000000"
            accessibilityLabel="Learn more about this purple button"
        />
    </View>
  )
}

const styles = StyleSheet.create({
        input: {
        height: 40,
        width: '100%',
        borderColor: 'gray',
        borderWidth: 1,
        paddingHorizontal: 10,
        borderRadius: 5,
    },
});
