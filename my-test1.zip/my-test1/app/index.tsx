import { View, Text } from 'react-native'
import React from 'react'
import { Link ,Stack} from "expo-router";


export default function index() {
  return (
    <View>
      <Stack.Screen options={{ title: "Profile Change" }} />
      <Text>index</Text>
      <Link href="/profile/user" > Profile </Link>
    </View>
  )
}