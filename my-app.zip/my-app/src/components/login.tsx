import { View, Text ,StyleSheet, TextInput , Button} from 'react-native'
import React , { useState }from 'react'

export default function login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handShow = () =>{
        console.log(username,password);
    } 

    return (
    <View>
        <TextInput
            style={styles.input}
            onChangeText={setUsername}
            value={username}
            placeholder="Digite seu nome"
        />

        <TextInput
            style={styles.input}
            onChangeText={setPassword}
            value={password}
            secureTextEntry 
            placeholder="Digite sua senha"
        />

        <Button
            onPress={handShow}
            title="Cadastrar"
            color="#841584"
            accessibilityLabel="Learn more about this purple button"
        />
    </View>
    )
}

const styles = StyleSheet.create({
        container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
        input: {
        height: 40,
        width: '100%',
        borderColor: 'gray',
        borderWidth: 1,
        paddingHorizontal: 10,
        borderRadius: 5,
    },
});