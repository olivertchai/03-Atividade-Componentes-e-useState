import { View, Text } from 'react-native'
import React, { Component, useEffect } from 'react'

export default function Aula() {
  console.log("Init!!")

  useEffect(() =>{},[]);//callback de inicialização do componente 


  return (
    <View>
      <Text>Aula</Text>
    </View>
  )
}