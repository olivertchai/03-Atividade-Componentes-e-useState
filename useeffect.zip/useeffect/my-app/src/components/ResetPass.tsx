import { View, StyleSheet, TextInput , Button,} from 'react-native'
import React , { useState , useEffect}from 'react'

export default function ResetPass() {
    const [password, setPassword] = useState('');  
    const [passwordConfirmation, setPasswordConfirmation] = useState('');
    const [passwordIsValid, setPasswordIsValid] = useState(false); // Adicionado


     useEffect(() => {
        const hasLettersNumbersSpecialChars = /^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[^a-zA-Z0-9\s]).+$/ .test(password);
        
        const isValid = password.length >= 6 && passwordConfirmation.length >= 6 && password === passwordConfirmation && hasLettersNumbersSpecialChars;
        setPasswordIsValid(isValid);
    }, [password, passwordConfirmation]);

    return (
    <View>
         <TextInput
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            secureTextEntry 
            placeholder="Digite sua senha"
        />

        <TextInput
            style={styles.input}
            value={passwordConfirmation}
            onChangeText={setPasswordConfirmation}
            secureTextEntry 
            placeholder="Digite sua senha"
        />
        <Button
            disabled = {!passwordIsValid} 
            title="reset"
            color="#000000"
            accessibilityLabel="Learn more about this purple button"
        />
    </View>
  )
}

const styles = StyleSheet.create({
        input: {
        height: 40,
        width: '100%',
        borderColor: 'gray',
        borderWidth: 1,
        paddingHorizontal: 10,
        borderRadius: 5,
    },
});

// Explicação do Código Corrigido
// Variável isValid: A linha const isValid = password.length >= 6 && passwordConfirmation.length >= 6 && password 
// === passwordConfirmation; agora declara uma variável isValid que recebe o resultado (true ou false) da sua 
// expressão de validação.

// useEffect Direto: A lógica de validação agora está diretamente dentro do useEffect,
// sem a necessidade de uma função aninhada.

// Atualização Consistente: A linha setPasswordIsValid(isValid); é executada em toda renderização acionada pelas 
// mudanças de password ou passwordConfirmation. Isso garante que o estado passwordIsValid sempre reflita a condição atual 
// dos campos de texto, habilitando ou desabilitando o botão corretamente.

// Em resumo, a chave para resolver o erro e fazer o código funcionar é declarar a variável de validação e garantir 
// que o useEffect sempre atualize o estado com o resultado da sua lógica.